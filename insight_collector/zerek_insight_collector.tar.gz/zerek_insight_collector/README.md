# ZEREK Insight Collector v2

Сбор бизнес-инсайтов из YouTube → `_insight.md` для RAG базы.

## Спецификация

- **33 ниши** (niche_queries.json, ID совпадают с niche_formats_*.xlsx)
- **3–7 видео** на нишу (топ по просмотрам)
- **≤5 лет** возраст видео
- **Только русский** язык (субтитры ru / auto-ru)
- **Только относительные показатели**: %, пропорции, сроки, коэффициенты
- **Без**: валют, цен, имён, городов, брендов, годов

## Локально

```bash
pip install -r requirements.txt
export YOUTUBE_API_KEY="..."
export GEMINI_API_KEY="..."

python collect_insights.py --list              # 33 ниши
python collect_insights.py --niche BARBER      # одна ниша
python collect_insights.py --batch             # все 33
```

## Railway

Variables:
```
YOUTUBE_API_KEY=...
GEMINI_API_KEY=...
OUTPUT_DIR=/app/output
```

API:
```
POST /collect         {"niche": "BARBER"}
POST /collect-batch   {"niches": ["COFFEE","DONER"]}
GET  /niches          список 33 ниш
GET  /results         готовые файлы
GET  /results/BARBER  содержимое файла
GET  /status          статус задач
```

## Добавить нишу

В `niche_queries.json`:
```json
"NEW_NICHE": {
  "name": "Название",
  "queries": [
    "как открыть [нишу]",
    "разбор бизнеса [ниши]",
    "открыть [нишу] с нуля",
    "сколько зарабатывает [ниша]",
    "[ниша] бизнес ошибки провал"
  ]
}
```

## Квоты

- YouTube: 10К юнитов/день. Search=100. 33 ниши × 5 запросов = 16500 → **2 дня на полный batch**
- Gemini Flash: ~1500 бесплатных запросов/день → запас огромный
- Транскрипты: бесплатно, без лимитов
